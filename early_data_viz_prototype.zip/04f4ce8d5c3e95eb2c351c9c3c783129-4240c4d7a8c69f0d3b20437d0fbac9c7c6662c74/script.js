d3.csv('https://assets.codepen.io/9330932/2010_top50.csv')
  .then(makeChart);

function makeChart(artists) {
  var artistLabels = artists.map(function(d) {return d.artist});
  var genreLabels = artists.map(function(d) {return d.top_genre});
  var energyLevels = artists.map(function(d) {return d.nrgy});
  var yearLabels = artists.map(function(d) {return d.year})
  var songLabels = artists.map(function(d) {return d.title})
  
  var chart = new Chart('chart', {
    type: 'horizontalBar',
    options: {
      maintainAspectRatio: false,
      legend: {
        display: false
      },
      scales: {
        xAxes: [
          {
            scaleLabel: {
              display: true,
              labelString: 'Energy Levels',
              fontSize: 15
            }
          }
        ]
      }
    },
    data: {
      labels: artistLabels,
      datasets: [
        {
          data: energyLevels
        }
      ]
    }
  });
}